// チャレンジ課題: 覆面算 AlphameticValue.java
