// チャレンジ課題: 覆面算 AlphameticValueTester.java
