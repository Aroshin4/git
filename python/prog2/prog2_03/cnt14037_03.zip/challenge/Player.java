// チャレンジ課題: 三山くずしゲーム Player.java
//
