// チャレンジ課題: 三山くずしゲーム Computer.java
